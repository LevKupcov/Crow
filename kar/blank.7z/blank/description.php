<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

$arTemplate = [
    'NAME' => 'FASTonline Blank',
    'DESCRIPTION' => 'Шаблон, подключающий статический проект FASTonline из каталога www/fastonline_static-main.',
];

