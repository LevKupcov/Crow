<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}
?>
</body>
<script defer src="/www/fastonline_static-main/docs/js/bundle.js"></script>
</html>

